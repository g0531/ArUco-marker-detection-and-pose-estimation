void mmal_core(void) {
}
