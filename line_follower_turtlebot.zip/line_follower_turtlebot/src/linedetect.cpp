/** MIT License
Copyright (c) 2017 Sudarshan Raghunathan
Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:
The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.
THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*
*
*@copyright Copyright 2017 Sudarshan Raghunathan
*@file linedetect.cpp
*@author Sudarshan Raghunathan
*@brief  Class linedetect's function definitions
*/
#include "linedetect.hpp"
#include <cv_bridge/cv_bridge.h>
#include <cstdlib>
#include <string>
#include <opencv2/highgui/highgui.hpp>
#include "ros/ros.h"
#include "opencv2/opencv.hpp"
#include "ros/console.h"
#include "line_follower_turtlebot/pos.h"

using namespace cv;

  // void LineDetect::imageCallback(const sensor_msgs::ImageConstPtr& msg) {
  void LineDetect::imageCallback(const sensor_msgs::CompressedImagePtr & msg) {
  cv_bridge::CvImagePtr cv_ptr;
  try {
    cv_ptr = cv_bridge::toCvCopy(msg, sensor_msgs::image_encodings::BGR8);
    img = cv_ptr->image;
    cv::waitKey(30);
  }
  catch (cv_bridge::Exception& e) {
    ROS_ERROR("Could not convert from ' ' to 'bgr8'.");
  }
}

  void LineDetect::DistanceCallback(const geometry_msgs::PoseStamped & msg ) {
  double x ;
  double y ;
  double z ;
  try {
    if(&msg != nullptr){
    x = msg.pose.position.x;
    y = msg.pose.position.y;
    z = msg.pose.position.z;
    LineDetect::distance = sqrt(pow(x,2)+pow(y,2));  
    ROS_INFO("distance %f",distance);
    }
    else{
    LineDetect::distance = 100;
    }
    cv::waitKey(30);
  }
  catch (cv_bridge::Exception& e) {
    ROS_ERROR("WRING   !!!.");
  }
}

cv::Mat LineDetect::Gauss(cv::Mat input) {
  cv::Mat output;
// Applying Gaussian Filter
  cv::GaussianBlur(input, output, cv::Size(3, 3), 0.1, 0.1);
  return output;
}

int LineDetect::colorthresh(cv::Mat input) {
  // Initializaing variables
  cv::Size s = input.size();
  std::vector<std::vector<cv::Point> > v;
  auto w = s.width;
  auto h = s.height;
  auto c_x = 0.0;
  // Detect all objects within the HSV range

  // cv::cvtColor(input, LineDetect::img_hsv, CV_BGR2GRAY);
  // cv::Mat img_mask;
  // img_mask(cv::Rect(0, 0, w, 0.8*h)) = 0;
  // cv::adaptiveThreshold(img_hsv,img_mask,255,ADAPTIVE_THRESH_MEAN_C,THRESH_BINARY,11,-2);
  // if(!img_mask.data){
  //   ROS_INFO("********************************************************nodata");
  // }

  cv::cvtColor(input, LineDetect::img_hsv, CV_BGR2HSV);
  LineDetect::LowerYellow = {0, 0, 0};
  LineDetect::UpperYellow = {180, 255, 70};
  cv::inRange(LineDetect::img_hsv, LowerYellow,
   UpperYellow, LineDetect::img_mask); 
  
  // Find contours for better visualization
  img_mask(cv::Rect(0, 0, w, 0.85*h)) = 0;
  cv::findContours(LineDetect::img_mask, v, CV_RETR_LIST, CV_CHAIN_APPROX_NONE);
  // If contours exist add a bounding
  // Choosing contours with maximum area

  if (v.size() != 0) {
  auto area = 0;
  auto idx = 0;
  auto count = 0;
  while (count < v.size()) {
    if (area < v[count].size()){
       idx = count;
       area = v[count].size();
    }
    count++;
  }
  cv::Rect rect = boundingRect(v[idx]);
  cv::Point pt1, pt2, pt3;
  pt1.x = rect.x;
  pt1.y = rect.y;
  pt2.x = rect.x + rect.width;
  pt2.y = rect.y + rect.height;
  pt3.x = pt1.x+5;
  pt3.y = pt1.y-5;
  // Drawing the rectangle using points obtained
  rectangle(input, pt1, pt2, CV_RGB(255, 0, 0), 2);
  // Inserting text box
  cv::putText(input, "Line Detected", pt3,
    CV_FONT_HERSHEY_COMPLEX, 1, CV_RGB(255, 0, 0));
  }
  // Mask image to limit the future turns affecting the output
  img_mask(cv::Rect(0.8*w, 0, 0.2*w, h)) = 0;
  img_mask(cv::Rect(0, 0, 0.2*w, h)) = 0;
  // Perform centroid detection of line
  cv::Moments M = cv::moments(LineDetect::img_mask);
  if (M.m00 > 0) {
    cv::Point p1(M.m10/M.m00, M.m01/M.m00);
    cv::circle(LineDetect::img_mask, p1, 5, cv::Scalar(155, 200, 0), -1);
  }
  c_x = M.m10/M.m00;
  // Tolerance to choose directions
  auto tol = 15;
  auto count = cv::countNonZero(img_mask);
  // Turn left if centroid is to the left of the image center minus tolerance
  // Turn right if centroid is to the right of the image center plus tolerance
  // Go straight if centroid is near image center
  if (c_x < w/2-tol) {
    LineDetect::dir = 0;
  } else if (c_x > w/2+tol) {
    LineDetect::dir = 2;
  } else {
    LineDetect::dir = 1;
  }
//  Search if no line detected
  // if (count == 0 && (LineDetect::dir == 2 || LineDetect::dir == 5)) {
  //   LineDetect::dir = 5;
  // }
  // if (count == 0 && (LineDetect::dir == 0 || LineDetect::dir == 3)) {
  //   LineDetect::dir = 3;
  // }
  // if (count == 0 && LineDetect::dir == 1){
  //   LineDetect::dir = 5;
  // }
  if(count == 0){
    LineDetect::dir = 3;
  }





  // //aruco detect part
  // cv::Ptr<aruco::Dictionary> dict = aruco::getPredefinedDictionary(aruco::PREDEFINED_DICTIONARY_NAME(aruco::DICT_6X6_250));
  // cv::Ptr<cv::aruco::DetectorParameters> params = aruco::DetectorParameters::create();
	// cv::Mat gray;
  // cv::cvtColor(input,gray,COLOR_BGR2GRAY);
	// std::vector<int> ids;
	// std::vector<std::vector<cv::Point2f>> corners, rejected;
	// cv::aruco::detectMarkers(gray, dict, corners, ids, params,rejected);
	// // if(ids.size() > 0) 
	// // {
	// // 	cv::aruco::drawDetectedMarkers(gray, corners, ids);
	// // 	cv::imshow("test", gray);
	// // 	cv::waitKey();
	// // }          
  // cv::Mat cameraMatrix = (cv::Mat_<double>(3,3) << 273.9783 ,    0.     ,  151.81899,  0.     ,  273.03021,  127.88242,    0.     ,    0.     ,    1.     );
  // cv::Mat distCoeffs = (cv::Mat_<double>(1,5)<< 0.135529, -0.197880, 0.009788, -0.003316, 0.000000);
  //   // if at least one marker detected
  // double distance;
  // if (ids.size() > 0) {
  //       cv::aruco::drawDetectedMarkers(input, corners, ids); 
  //       std::vector<cv::Vec3d> rvecs, tvecs;
  //       cv::aruco::estimatePoseSingleMarkers(corners, 0.0125, cameraMatrix, distCoeffs, rvecs, tvecs);
  //       // draw axis for each marker
  //       for(int i = 0; i < ids.size();i++){
  //         cv::aruco::drawAxis(input,cameraMatrix,distCoeffs,rvecs[i],rvecs[i],0.1);
  //       }
  //       distance = (tvecs[0][0]+ 0.02)*1000;
  //       std::cout << "distance:"<<distance<<"mm"<<std::endl;
  //       if(distance<=100){
  //           LineDetect::dir = 4;
  //       }
  // }
  // Output images viewed by the turtlebot

  if(distance <= 0.04){
    LineDetect::dir = 4;
  }
  else if(distance<=0.07){
    LineDetect::dir = 5;
  }
  namedWindow("Turtlebot View");
  imshow("Turtlebot View", input);
  return LineDetect::dir;

}

