var searchData=
[
  ['dir_5fsub',['dir_sub',['../classturtlebot.html#a086689860adb5ae052b5b89b17a79b7d',1,'turtlebot']]],
  ['drive_5fstraight',['drive_straight',['../test__detect_8cpp.html#adafa16f901d157cb8393ac413808231a',1,'test_detect.cpp']]]
];
